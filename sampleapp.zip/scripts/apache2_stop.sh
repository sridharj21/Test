#!/bin/bash

sudo systemctl stop apache2

